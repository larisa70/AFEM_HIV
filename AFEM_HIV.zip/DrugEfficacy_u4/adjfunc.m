function [ adjf ] = adjfunc(lambda,u,g,eta)
  %The  rhs f(lambda) in the adjoint problem: lambda'=f(lambda)

adjf=zeros(4,1);  

s=10;
mu=0.01;
k=2.4e-5;
mu1=0.015;
alfa=0.4;
b=0.05;
delta=0.26;
c=2.4;
N=1000;


adjf(1)=  lambda(1)*k*u(4) +lambda(1)*mu - lambda(2)*k*u(4);        
adjf(2)=  lambda(2)*(mu1 + alfa + b) - lambda(1)*(eta*alfa + b) -(1-eta)*alfa*lambda(3);
adjf(3)=  lambda(3)*delta -lambda(4)*N*delta;

% different versions for observations of u_4: or we have g(4), or not.

%adjf(4)=  lambda(4)*c + lambda(1)*k*u(1) -lambda(2)*k*u(1) + u(4) - g(4);

adjf(4)=  lambda(4)*c + lambda(1)*k*u(1) -lambda(2)*k*u(1) + u(4);

end


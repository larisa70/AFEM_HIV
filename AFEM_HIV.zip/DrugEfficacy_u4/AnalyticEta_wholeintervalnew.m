function [eta_guess,g_obs] = AnalyticEta_wholeintervalnew(ext_eta,time_mesh,obs_start,obs_end,noise_flag,noise_level,meshref)
    delta = 0.26;                       %Value of parameter delta.
    alfa=0.4;                           %Value of parameter alpha
    %final_time = time_mesh(end);
    nodes = length(time_mesh)-1;
    time_step = zeros(1,length(time_mesh));
    for i = 1:length(time_step)-1
        time_step(i) = time_mesh(i+1)-time_mesh(i);
    end                                 %Time step for discrete derivatives.
    g_prim = zeros(4,nodes+1);
    eta = zeros(1,nodes+1);
    %Simulate the true values of the model problem, with and without noise.
    [g,g_brus,g_add] =  ExactNewton(ext_eta,time_mesh,noise_level);
    if noise_flag == 1
        g_obs = g_brus;
    elseif noise_flag == 2
        g_obs = g_add;
    else
        g_obs = g;
    end
%****************  before plotting data and fitting to data (initial guess for eta)***********************************

figure
plot(time_mesh, g(4,:),'-* b', 'linewidth',2)
hold on

%*********  we zero out observation data outside the observation interval
final_time = time_mesh(end); % the final time
t=0; 
dt = zeros(1,length(time_mesh));
 g_obs(4,length(dt)) = 0;
for i = 1:length(dt)-1
    dt(i) = time_mesh(i+1)-time_mesh(i);   %Time step
     
   if t >= obs_end || t <= obs_start
     
         g_obs(4,i) = 0;
    end
    
    t=t+dt(i);
     
end

g_obs(4,:)


plot(time_mesh,g_obs(4,:),'o ', 'linewidth',2)


xlabel('Time')
ylabel('u_4')
legend('simulated u_4',' noisy u_4');
title(['Nr. of ref.: ',num2str(meshref-1),' number of input points ',num2str(nodes+1),',  \sigma= ',num2str(noise_level*100),'%'])

hold off
%******************************  end of plotting ***********************************************************
    
    t=0;
%Compute derivatives of g.
    for i = 1:nodes
        g_prim(:,i+1) = (g_obs(:,i+1)-g_obs(:,i))/time_step(i);
    end
    g_prim(:,1) = 2*g_prim(:,2)-g_prim(:,3);
    %Compute analytic eta inside observation interval.
    for i = 1:nodes+1
        eta(i) = 1 - (delta*g_obs(3,i)+g_prim(3,i))/(alfa*g(2,i));

        
if eta(i) > 1.0
eta(i) = 1.0;
end
if eta(i) < 0
eta(i) = 0;
end
   
    
    end
  
   
    
    eta_guess = eta;
  % plot(time_mesh,eta_guess,'o')

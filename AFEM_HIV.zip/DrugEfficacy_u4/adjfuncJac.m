function [adjJac] = adjfuncJac(u,eta)
% The Jacobian for the adjoint problem
% Input: u      (point)
% Output: adjJac   (Jacobian for the adjoint equation in point u)

k=2.4e-5;
mu=0.01;
mu1=.015;
alpha=0.4;
b=0.05;
delta=0.26;
c=2.4;
N=1000;


adjJac=[k*u(4) + mu,-k*u(4), 0, 0;
	-(eta*alpha + b), mu1 + alpha + b, (eta-1)*alpha, 0;
	 0, 0, delta, -N*delta;
	 k*u(1), -k*u(1), 0, c;];


end




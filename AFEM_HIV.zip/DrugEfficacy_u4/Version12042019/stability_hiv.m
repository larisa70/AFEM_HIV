function [estimate] = stability_hiv(eta)

s=10;
mu=0.01;
k=2.4e-5;
mu1=0.015;
alfa=0.4;
b=0.05;
delta=0.26;
c=2.4;
N=1000;

T = (mu1+alfa+b)*c/(N*alfa*k*(1-eta));
Tstar1 = (s-mu*T)/(mu1+alfa*(1-eta));
Tstar = alfa*(1-eta)*Tstar1/delta;
V = N*delta*Tstar/c;

A = mu + k*V + mu1 + alfa + b + delta + c;
B = (c+delta)*(alfa+mu1+mu+k*V+b) + c*delta + mu*(mu1+alfa+b) + k*V*(mu1 + (1-eta)*alfa);
C = c*delta*(mu + k*V) + (c+delta)*(mu*mu1 + mu*alfa + mu*b + mu1*k*V + (1-eta)*alfa*k*V);
D = c*delta*k*V*(mu + alfa*(1-eta));
DELTA = A*B - C;

estimate = DELTA*C - A^2*D;
end

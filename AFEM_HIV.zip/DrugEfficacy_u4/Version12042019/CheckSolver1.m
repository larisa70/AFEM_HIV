%% Specify fixed parameter values.
clear all
%Time parameters ----------------------------------------------------------
final_time = 500;
obs_start = 1;            %Starting time for observations of true solution.
obs_end = 500;            %End time for observations of true solution.
%Parameters from the model problem ----------------------------------------
alfa=0.4;                 %Value of parameter alpha.
%Optimization parameters --------------------------------------------------
gamma_start = 0.1;        %Initial value of regularization parameter.
opt_step_length = 0.001;  %Step length in optimization algorithm.
optim_maxiter = 500;      %Maximum iterations of optimization alg.
%Noise --------------------------------------------------------------------
noise_level = 0.03;   %Noise level of observations.
noise_flag = 0;       % 0 = no noise, 1 = random noise, 2 = additive noise.

%% Create initial time mesh, observations and starting guess for parameter eta.
time_mesh = 0:final_time; % will be adaptively updated.
refined = time_mesh;
%Values for parameter eta -------------------------------------------------
scaling_factor = 0.7;
function_flag = 3;       %eta(t) = scaling_factor*function
%ext_eta = ExactEta(scaling_factor,function_flag,time_mesh);
%Function flag: 0. const. 1. +linear 2. -linear 3. sin 4. exp(-x)
%NB! For now, we will specify these values inside the time-adaptive loop
%instad.
%They will be moved back here at a later stage.
%[eta_guess,g] = AnalyticEta(ext_eta,time_mesh,obs_start,obs_end,noise_flag,noise_level);
%Input: 1. exact eta 2. time mesh 3. observation start 4. observation end. 5. noise_flag. 6. noise level

%% Run algorithm
  
    time_mesh = refined;                                        %Our new time mesh (if mesh refinement has been made.
    ext_eta = ExactEta(scaling_factor,function_flag,time_mesh); %Exact eta.
    [eta_guess,g] = AnalyticEta(ext_eta,time_mesh,obs_start,obs_end,noise_flag,noise_level); %Observations and first guess for eta.
    nodes = length(time_mesh);                                  %Number of nodes in the present time mesh.
    eta = zeros(optim_maxiter,nodes);                           %Preallocation of eta (for use in for-loop).
    eta(1,:) = eta_guess;                                       %First guess for eta in first row.
    beta = opt_step_length*ones(1,nodes);                       %
    gamma = gamma_start;                                        %Restore beta and gamma.
    big_grad = zeros(1,nodes);                                  %Preallocation of vector for adaptivity.
    u1 = ForwardNewton(eta(1,:),time_mesh);                     %Compute initial forward sol.
    lambda1 = AdjointNewton(eta(1,:),u1,g,time_mesh,obs_start,obs_end);   %Compute adjoint sol.
    g0 = -alfa*u1(2,:).*(lambda1(1,:)-lambda1(3,:));            %Compute grad.
  
figure
plot(time_mesh,ext_eta,'LineWidth',2)
	 
		   hold on
plot(time_mesh,eta_guess,'LineWidth',2)
		   

		   legend('exact \eta','guess for \eta')

		   
figure
plot(time_mesh,lambda1,'LineWidth',2)

	
title('Solution of the adjoint problem \lambda_1 ')

figure		   
plot(time_mesh,g0,'LineWidth',2)
title('gradient  g0')		   
		   
%figure
%plot(time_mesh,lambda1,'LineWidth',2)
%title('Solution of the adjoint problem')

		   dif_obs = u1-g;
figure
plot(time_mesh, dif_obs,'LineWidth',2)
title(' u1 - g')

		   figure
plot(time_mesh, u1,'LineWidth',2)
title(' Forward problem solution u1')

 figure										    
plot(time_mesh, g,'LineWidth',2)
title(' Observations g')

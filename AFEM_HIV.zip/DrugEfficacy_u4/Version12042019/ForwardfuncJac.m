function [Jac ] = funcJac(u,eta)
% The Jacobian for our problem
% Input: u      (point)
% Output: Jac   (Jacobian in point u)

k=2.4e-5;
mu=0.01;
mu1=.015;
alpha=0.4;
b=0.05;
delta=0.26;
c=2.4;
N=1000;


Jac=[-k*u(4) - mu, eta*alpha + b, 0, -k*u(1);
       k*u(4), -(mu1 + alpha + b),0, k*u(1);
       0, (1- eta)*alpha, -delta, 0;
       0,0, N*delta, -c];

end


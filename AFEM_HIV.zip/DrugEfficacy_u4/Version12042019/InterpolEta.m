%% Clear variables and windows
clear all
close all

%% Create observation values
time_mesh = 0:0.2:1000;

%eta = 0.8*sin(3*time_mesh/1000);
%eta = 0.8*ones(1,length(time_mesh));
eta = 0.8*exp(-0.01*time_mesh);
%eta = 0.8*time_mesh.^2/1e+6;

noise_level = 0.01;

[g,g_brus,g_add] = ExactNewton(eta,time_mesh,noise_level);

observation_points = 5;
step_size = floor(length(time_mesh)/observation_points);

g_obs = g_brus(:,1:step_size:end);
t_obs = time_mesh(1:step_size:end);

%% Interpolate to get approximate observation values

pol_deg = min(observation_points-1,18);

P = zeros(4,pol_deg+1);

%Interpolation and smoothing of data using smoothing splines -------------
[p_smooth1, P1] = csaps(t_obs,g_obs(1,:));
[p_smooth2, P2] = csaps(t_obs,g_obs(2,:));
[p_smooth3, P3] = csaps(t_obs,g_obs(3,:));
[p_smooth4, P4] = csaps(t_obs,g_obs(4,:));

sply = zeros(4,length(time_mesh));

sply(1,:) = ppval(p_smooth1,time_mesh);
sply(2,:) = ppval(p_smooth2,time_mesh);
sply(3,:) = ppval(p_smooth3,time_mesh);
sply(4,:) = ppval(p_smooth4,time_mesh);
%-------------------------------------------------------------------------
%Polynomial fitting using Vandermonde matrix -----------------------------
[P(1,:),S1,MU1] = polyfit(t_obs,g_obs(1,:),pol_deg);
[P(2,:),S2,MU2] = polyfit(t_obs,g_obs(2,:),pol_deg);
[P(3,:),S3,MU3] = polyfit(t_obs,g_obs(3,:),pol_deg);
[P(4,:),S4,MU4] = polyfit(t_obs,g_obs(4,:),pol_deg);

Y = zeros(4,length(time_mesh));
Y(1,:) = polyval(P(1,:),time_mesh,[],MU1);
Y(2,:) = polyval(P(2,:),time_mesh,[],MU2);
Y(3,:) = polyval(P(3,:),time_mesh,[],MU3);
Y(4,:) = polyval(P(4,:),time_mesh,[],MU4);
%-------------------------------------------------------------------------
%Visualization of the results---------------------------------------------
%figure
%plot(time_mesh,g(1,:))
%hold on
%plot(time_mesh,Y(1,:))
%plot(time_mesh,sply(1,:),':')

%figure
%plot(time_mesh,g(2,:))
%hold on
%plot(time_mesh,Y(2,:))
%plot(time_mesh,sply(2,:),':')

%figure
%plot(time_mesh,g(3,:))
%hold on
%plot(time_mesh,Y(3,:))
%plot(time_mesh,sply(3,:),':')

%figure
%plot(time_mesh,g(4,:))
%hold on
%plot(time_mesh,Y(4,:))
%plot(time_mesh,sply(4,:),':')

figure
plot(time_mesh,g,'LineWidth',2)
hold on
plot(time_mesh,Y,'--','LineWidth',2)
plot(time_mesh,sply,':','LineWidth',2)
title('Interpolated forward solution. Whole line = exact, dashed = least squares, dotted = smoothing splines')

%% Deduce parameter Eta, by solving this system

    delta = 0.26;                       %Value of parameter delta.
    alfa=0.4;                           %Value of parameter alpha.
    nodes = length(time_mesh);
    time_step = zeros(1,nodes-1);
    for i = 1:nodes-1
        time_step(i) = time_mesh(i+1)-time_mesh(i);
    end                                 %Time step for discrete derivatives.
    Y_prim = zeros(4,nodes);
    sply_prim = Y_prim;
    eta_calc = zeros(1,nodes);
    eta_spline = eta_calc;

%Compute derivatives of g.
    for i = 1:nodes-1
        Y_prim(:,i+1) = (Y(:,i+1)-Y(:,i))/time_step(i);
        sply_prim(:,i+1) = (sply(:,i+1)-sply(:,i))/time_step(i);
    end
    Y_prim(:,1) = min(0,2*Y_prim(:,2)-Y_prim(:,3));
    sply_prim(:,1) = min(0,2*sply_prim(:,2)-sply_prim(:,3));
    %Compute analytic eta inside observation interval.
    for i = 1:nodes
        eta_calc(i) = 1 - (delta*Y(3,i)+Y_prim(3,i))/(alfa*Y(2,i));
        eta_spline(i) = 1 - (delta*sply(3,i)+sply_prim(3,i))/(alfa*sply(2,i));
    end

%Remove singularities by Hampel filtering
if min(Y(2,:)) < 0.1
    eta_filter = hampel(eta_calc,floor(0.1*nodes),2);
else
    eta_filter = eta_calc;
end

if min(sply(2,:)) < 0.1
    eta_f_spline = hampel(eta_spline,floor(0.1*nodes),2);
else
    eta_f_spline = eta_spline;
end 

%Force eta to belong to [0,1]
    for i = 1:nodes
        if eta_filter(i) < 0
            eta_filter(i) = 0;
        elseif eta_filter(i) > 1
            eta_filter(i) = 1;
        end
        if eta_f_spline(i) < 0
            eta_f_spline(i) = 0;
        elseif eta_f_spline(i) > 1
            eta_f_spline(i) = 1;
        end
    end
        
%% Visualize data

figure
%plot(time_mesh,eta_calc)
plot(time_mesh,eta_filter,'LineWidth',2)
hold on
plot(time_mesh,eta_f_spline,'LineWidth',2)
plot(time_mesh,eta,'LineWidth',2)
title('Solution of inverse problem.')
legend('least squares','smoothing splines','exact')
xlabel('time')
ylabel('\eta')

figure
plot(time_mesh,eta-eta_filter,'LineWidth',2)
hold on
plot(time_mesh,eta-eta_f_spline,'LineWidth',2)
title('Error of the solution.')
legend('Least squares','Smoothing splines')
xlabel('time')
ylabel('error')

function [eta_guess,g_obs] = AnalyticEta(ext_eta,time_mesh,obs_start,obs_end,noise_flag,noise_level)
    delta = 0.26;                       %Value of parameter delta.
    alfa=0.4;                           %Value of parameter alpha
    %final_time = time_mesh(end);
    nodes = length(time_mesh)-1;
    time_step = zeros(1,length(time_mesh));
    for i = 1:length(time_step)-1
        time_step(i) = time_mesh(i+1)-time_mesh(i);
    end                                 %Time step for discrete derivatives.
    g_prim = zeros(4,nodes+1);
    eta = zeros(1,nodes+1);
    %Simulate the true values of the model problem, with and without noise.
    [g,g_brus,g_add] = ExactNewton(ext_eta,time_mesh,noise_level);
    if noise_flag == 1
        g_obs = g_brus;
    elseif noise_flag == 2
        g_obs = g_add;
    else
        g_obs = g;
    end

%Compute derivatives of g.
    for i = 1:nodes
        g_prim(:,i+1) = (g_obs(:,i+1)-g_obs(:,i))/time_step(i);
    end
    g_prim(:,1) = 2*g_prim(:,2)-g_prim(:,3);
    %Compute analytic eta inside observation interval.
    for i = 1:nodes+1
        eta(i) = 1 - (delta*g_obs(3,i)+g_prim(3,i))/(alfa*g(2,i));
    end
    
    %Smoothe noise
    if noise_flag ~= 0
        N = length(eta);
        e = ones(N,1);
        D = spdiags([e -2*e e], 0:2, N-2, N);
        F = speye(N) + 50*(D'*D);
        eta_smooth = F\eta';
		   
    end

			   for i=1:N
			   if  eta_smooth(i) > 1 
			   eta_smooth(i) = 1;
			   end
			   if  eta_smooth(i) < 0 
			   eta_smooth(i) = 0;
			   end
			   end
			   
    time = 0;
    start_ind = 1;
    while time < obs_start
        time = time + time_step(start_ind);
        start_ind = start_ind + 1;
    end

    time = 0;
    end_ind = 1;
    while time < obs_end
        time = time + time_step(end_ind);
        end_ind = end_ind + 1;
    end

    if noise_flag ~= 0
			   eta_obs = eta_smooth(1+start_ind:end_ind);  % for smoothed data
    else
        eta_obs = eta(1+start_ind:end_ind)';
    end
    

max(eta_obs)

    Lin_ext = floor(nodes/10);
    
    V2 = ones(Lin_ext,2);
    V1 = V2;
    x = zeros(1,Lin_ext);
    y = x;
    x(end) = obs_end;
    y(1) = obs_start;
    for i = 1:Lin_ext-1
        x(Lin_ext-i) = x(Lin_ext+1-i) - time_step(end_ind - i);
        y(i+1) = y(i) + time_step(start_ind + i - 1);
    end
    V2(:,2) = x';
    V1(:,2) = y';
    %size(V2)
    %size(eta_obs(end-(Lin_ext-1):end))
    %pause
    l_ext2 = V2\eta_obs(end-(Lin_ext-1):end);
    l_ext1 = V1\eta_obs(1:Lin_ext);
    %plot(1:50,eta_obs(1:50))
    %l_ext2
    %l_ext1
    %pause
    eta_guess = zeros(1,length(eta));
    for i = 1+start_ind:end_ind
        eta_guess(i) = eta_obs(i-start_ind);
%if eta_guess(i) > 1
%eta_guess(i)
%end
    end

    l = 0;

    for i = 1:start_ind
        eta_guess(i) = l_ext1(1) + l_ext1(2)*l;
if eta_guess(i) > 1
eta_guess(i)
end
        l = l + time_step(i);
    end

    k = obs_end + time_step(end_ind);

    for i = 1+end_ind:nodes+1
        eta_guess(i) = l_ext2(1) + l_ext2(2)*k;
        k = k + time_step(i);
if eta_guess(i) > 1
eta_guess(i)
end
    end
    
end

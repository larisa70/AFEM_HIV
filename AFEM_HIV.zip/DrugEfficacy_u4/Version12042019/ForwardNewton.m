%Computes the forward solution of the model problem.
function [u] = ForwardNewton(eta,time_mesh)
t=0;  % initial time

%final_time = time_mesh(end);
nodes = length(time_mesh)-1;

ustart = [300;10;10;10];    %Initial values for u - write correct values
            
v=ustart;

%nodes = 100;
MaxIter = 1000;  % maximal number of iterations in Newton method

u = zeros(4,nodes+1);
u(:,1) = ustart;
%u_hist=[u];     %Save all u values for later plot

%final_time = 1000; % here we choose final time
dt = zeros(1,length(time_mesh));
for i = 1:length(dt)-1
    dt(i) = time_mesh(i+1)-time_mesh(i);   %Time step
end

for i = 1:nodes   % Here we define final time
    tol=1;
    iter=0;
    while tol>10^(-10) && iter < MaxIter   %Newton iterations
%    F= v-u(:,i)-dt*Forwardfunc(v,eta(i));
%    J=eye(length(ustart)) - dt.*ForwardfuncJac(v,eta(i));
    F= v-u(:,i)-dt(i)*Forwardfunc(v,eta(i));
    J=eye(length(ustart)) - dt(i)*ForwardfuncJac(v,eta(i));
    dv = -J\F;
     v=v+dv;              %The Newton iteration 
     iter = iter +1;
     tol = norm(dv,inf);
    end  
    if iter==MaxIter        %If the Newton meth. does not converge
        disp('No convergence in the Newton method')
        break
    end
   %   disp('Newton method converged at iteration:')
    %  iter
    if v(1) < 0 || v(2) < 0 || v(3) < 0 || v(4) < 0
        warning('Forward solution algorithm yields invalid solution. Try increasing the number of nodes in the time partition.')
        return
    end
    u(:,i+1) =  v;        
    t=t+dt;
   %u_hist=[u_hist,u];

end

% to see only u2:
% plot(0:1/length(u(1,:)):(1-1/length(u(1,:))),u(2,:))

%here we defime mesh for time
%time_mesh=0:dt:final_time;

%figure
%plot(time_mesh,u,'LineWidth',2)

%xlabel('time interval');
%ylabel('solution');

%legend('u_1','u_2','u_3','u_4');

%str_title = ['forward solution for eta=', num2str(eta)];
%title(str_title)

end


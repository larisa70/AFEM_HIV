function [ f ] = func(u,eta)
%The function f in the problem: u'=f(u)

f=zeros(4,1);  

s=10;
mu=0.01;
k=2.4e-5;
mu1=0.015;
alfa=0.4;
b=0.05;
delta=0.26;
c=2.4;
N=1000;


f(1)=s-k*u(1)*u(4)-mu*u(1)+eta*alfa*u(2)+b*u(2);        
f(2)=k*u(1)*u(4)-mu1*u(2)-alfa*u(2)-b*u(2); 
f(3)=alfa*u(2)-eta*alfa*u(2)-delta*u(3);
f(4)=N*delta*u(3)-c*u(4); 
end


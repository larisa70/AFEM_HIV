function ext_eta = ExactEta(scaling,flag,time_mesh)
%Input: 1. scaling factor
%2. function flag (0. const. 1. +linear 2. -linear 3. sin 4. exp(-x))
%time = 0;
s = zeros(1,length(time_mesh));
for i = 1:length(time_mesh)
    s(i) = 3*time_mesh(i)/time_mesh(end);
end
    if flag == 1
        ext_eta = scaling*s/3;
    elseif flag == 2
        ext_eta = scaling*(1-s/3);
    elseif flag == 3
        ext_eta = scaling*sin(s);
    elseif flag == 4
        ext_eta = scaling*exp(-s);
       elseif flag == 5
        ext_eta = scaling*exp(-s) + 0.05;  
    else
        ext_eta = scaling*ones(1,length(time_mesh));
    end
end
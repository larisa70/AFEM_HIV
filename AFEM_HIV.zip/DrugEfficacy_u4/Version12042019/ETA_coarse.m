%% Specify fixed parameter values.
clear all
%Time parameters ----------------------------------------------------------
final_time = 500;
obs_start = 0;            %Starting time for observations of true solution.
obs_end = 500;            %End time for observations of true solution.
%Parameters from the model problem ----------------------------------------
alfa=0.4;                 %Value of parameter alpha.
%Optimization parameters --------------------------------------------------
gamma_start = 0.1;        %Initial value of regularization parameter.
opt_step_length = 0.001;  %Step length in optimization algorithm.
optim_maxiter = 500;      %Maximum iterations of optimization alg.
%Noise --------------------------------------------------------------------
noise_level = 0.03;   %Noise level of observations.
noise_flag = 0;       % 0 = no noise, 1 = random noise, 2 = additive noise.

%% Create initial time mesh, observations and starting guess for parameter eta.
time_mesh = 0:final_time; % will be adaptively updated.
refined = time_mesh;
%Values for parameter eta -------------------------------------------------
scaling_factor = 0.7;
function_flag = 3;       %eta(t) = scaling_factor*function
%ext_eta = ExactEta(scaling_factor,function_flag,time_mesh);
%Function flag: 0. const. 1. +linear 2. -linear 3. sin 4. exp(-x)
%NB! For now, we will specify these values inside the time-adaptive loop
%instad.
%They will be moved back here at a later stage.
%[eta_guess,g] = AnalyticEta(ext_eta,time_mesh,obs_start,obs_end,noise_flag,noise_level);
%Input: 1. exact eta 2. time mesh 3. observation start 4. observation end. 5. noise_flag. 6. noise level

%% Run algorithm
    figure
for bla = 1:1            %Outer loop is for time adaptivity, will be replaced with while loop later.
    time_mesh = refined;                                        %Our new time mesh (if mesh refinement has been made.
    ext_eta = ExactEta(scaling_factor,function_flag,time_mesh); %Exact eta.
    [eta_guess,g] = AnalyticEta(ext_eta,time_mesh,obs_start,obs_end,noise_flag,noise_level); %Observations and first guess for eta.
    nodes = length(time_mesh);                                  %Number of nodes in the present time mesh.
    eta = zeros(optim_maxiter,nodes);                           %Preallocation of eta (for use in for-loop).
    eta(1,:) = eta_guess;                                       %First guess for eta in first row.
    beta = opt_step_length*ones(1,nodes);                       %
    gamma = gamma_start;                                        %Restore beta and gamma.
    big_grad = zeros(1,nodes);                                  %Preallocation of vector for adaptivity.
    u1 = ForwardNewton(eta(1,:),time_mesh);                     %Compute initial forward sol.
    lambda1 = AdjointNewton(eta(1,:),u1,g,time_mesh,obs_start,obs_end);   %Compute adjoint sol.
    g0 = -alfa*u1(2,:).*(lambda1(1,:)-lambda1(3,:));            %Compute grad.
    grad_hist = zeros(optim_maxiter,nodes);
    grad_hist(1,:) = g0;                                        %Save gradient for later plot.
    if norm(g0) < 1000
        eta(1:end,:) = ones(length(1:optim_maxiter),1)*eta(1,:);    %Check if gradient is already small
        disp('The algorithm has converged at first step!')
        break
    end
    bm = 1/gamma;                                               %For Conjugate Gradient algorithm.
    gn = -g0;
    dn = gn;
    g0 = sign(g0);                                                  %Normalize gradient.
    eta(2,:) = eta(1,:) + beta.*g0;                                 %Compute new eta.
    %iter = 0;
    for i = 2:optim_maxiter-1                                       %Here we start calculating eta.
        gamma = gamma/i^0.5;                                        %Update gamma.
        u = ForwardNewton(eta(i,:),time_mesh);                      %Update forward and adjoint sol.
        lambda = AdjointNewton(eta(i,:),u,g,time_mesh,obs_start,obs_end);
        gm = gamma*(eta(i,:)-eta(1,:)) - alfa*u(2,:).*(lambda(1,:)-lambda(3,:));         %Update gradient.
        bs = (norm(gm)/norm(gn))^2;                                 %For CG.
        dm = -gm + bs*dn;
        bm = -(gm*dn')/(gamma*(dn*dn'));                            %beta = -<g,d>/gamma<d,d>
        grad_hist(i,:) = gm;                                        %Save gradient for later plot.
        if norm(gm) < 1000                                          %Check if gradient is small enough.
            eta(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*eta(i,:);
            grad_hist(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*grad_hist(i,:);
            disp('The algorithm has converged!')
            break
        elseif 0.999999*norm(eta(i-1,:)) < norm(eta(i,:)) && norm(eta(i,:)) < 1.000001*norm(eta(i-1,:))
            eta(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*eta(i,:);
            grad_hist(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*grad_hist(i,:);
            disp('Eta does not change!')                            %Also terminate if eta stabilizes.
            break
        %elseif norm(grad_hist(i-1,:)) < norm(grad_hist(i,:))
        %    eta(i+1,:) = eta(i,:) + 0.5*beta.*sign(grad_hist(i,:));
        %    eta(i+2:end,:) = ones(length(i+2:optim_maxiter),1)*eta(i+1,:);
        %    disp('Gradient grows.')
        %    break
        %    %Termination if the gradient increases turned out to give
        %    worse results, and is therefore disabled.
        else
            gm = sign(gm);                                      %Otherwise, continue with line search.
            for j = 1:nodes
                if eta(i,j) < 0                                 %Force eta=0 if computed eta is negative.
                    eta(i+1,j) = 0;
                elseif eta(i,j) > 1                             %Force eta=1 if computed eta > 1.
                    eta(i+1,j) = 1;
                elseif bm < 0.01
                    eta(i+1,j) = eta(i,j) + bm*gm(j);           %Use conjugate gradient if appropriate.
                else
                    if gm(j) == -gn(j)                          %Otherwise use fixed step length.
                        beta(j) = beta(j)/2;                    %If gradient change sign, halve step-length.
                    end
                    eta(i+1,j) = eta(i,j) - beta(j)*gm(j);      %Compute new eta closer to the actual solution. 
                end
            end
        end
        gn = gm;                %Save gradient for use in the CG algorithm.
        dn = dm;
        %iter = iter + 1;
    end
    
    for j = 1:length(big_grad)  %Check where the gradient is large.
        if abs(grad_hist(end,j)) > 0.2*max(abs(grad_hist(end,:)))
            big_grad(j) = 1;
        end
    end
   
    hold on
    plot(time_mesh, eta(end,:)) %Plot calculated eta for each iteration in time adaptive algorithm.
end
    %include time partitioning
%% Visualize solution
figure
surf(eta)
xlabel('time partition');
ylabel('iteration');
zlabel('eta');
title('Computed drug efficiency, eta');

%figure
%surf(grad_hist)
%xlabel('time partition');
%ylabel('iteration');
%zlabel('gradient');
%title('Gradient of the functional');

%% Apply least-squares smoothing on the solution

eta_final = eta(end,:);
N = length(eta_final);
e = ones(N,1);
D = spdiags([e -2*e e], 0:2, N-2, N);
F = speye(N) + 50*(D'*D);
eta_smooth = F\eta_final';

figure
plot(time_mesh,ext_eta,'LineWidth',2)
	 
		   hold on
plot(time_mesh,eta_guess,'LineWidth',2)
		   
plot(time_mesh,eta_smooth,'LineWidth',2)
		   legend('exact \eta','guess for \eta','computed \eta')
title('Calculated drug efficiency')
		   
figure
plot(time_mesh,lambda,'LineWidth',2)

	
title('Solution of the adjoint problem ')

figure		   
plot(time_mesh,gm,'LineWidth',2)
title('gradient')		   
		   
%figure
%plot(time_mesh,lambda1,'LineWidth',2)
%title('Solution of the adjoint problem')

		   dif_obs = u-g;
figure
plot(time_mesh, dif_obs,'LineWidth',2)
title(' u-g')

		   dif_obs1 = u1-g;
figure
plot(time_mesh, dif_obs1,'LineWidth',2)
title(' u_1 - g')

		   figure
plot(time_mesh, u,'LineWidth',2)
title(' Forward problem solution u')

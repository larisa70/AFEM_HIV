%% Specify fixed parameter values.
clear all
close all
%Time parameters ----------------------------------------------------------
final_time = 300;
obs_start = 25;            %Starting time for observations of true solution.
%obs_start = 21;   
obs_end = 300;            %End time for observations of true solution.
%Parameters from the model problem ----------------------------------------
alfa=0.4;                 %Value of parameter alpha.
%Optimization parameters --------------------------------------------------
gamma_start = 0.1;        %Initial value of regularization parameter.
opt_step_length = 0.001;  %Step length in optimization algorithm.
optim_maxiter = 500;      %Maximum iterations of optimization alg.
%Noise --------------------------------------------------------------------
%noise_level = 0.01;   %Noise level of observations.
noise_level = 0.05;   %Noise level of observations.
noise_flag = 1;       % 0 = no noise, 1 = random noise, 2 = additive noise.

%% Create initial time mesh, observations and starting guess for parameter eta.
%time_mesh = 0:final_time; % will be adaptively updated.
m=15;  %number of initial observations (number of initial points in the time-mesh)
time_mesh =linspace(0,final_time ,m);

refined = time_mesh;
%Values for parameter eta -------------------------------------------------
scaling_factor = 0.7;
function_flag = 5;       %eta(t) = scaling_factor*function
  %function flag can be between 1 and 4, determines model function
  
%ext_eta = ExactEta(scaling_factor,function_flag,time_mesh);
%Function flag: 0. const. 1. +linear 2. -linear 3. sin 4. exp(-x)  5. scaling*exp(-s) +2.0

%[eta_guess,g] = AnalyticEta(ext_eta,time_mesh,obs_start,obs_end,noise_flag,noise_level);
%Input  parameters: 1. exact eta 2. time mesh 3. observation start 4. observation end. 5. noise_flag. 6. noise level

eps = 10^(-7);
%% Run algorithm
 %   figure
for meshref = 1:4
    
    
    %This loop is for time adaptivity, will be replaced with while loop later.

	
			  
	    time_mesh = refined;                                        %Our new time mesh (if mesh refinement has been made.
	  m=size(time_mesh,2);
      
      %compute smallest and largest time steps
     for i=1:m-1
        tau = time_mesh(1,i+1) - time_mesh(1,i);
        array_tau(i) = tau;
     end
      
     max_time_step = max(array_tau);
     min_time_step =  min(array_tau);
      
      ext_eta = ExactEta(scaling_factor,function_flag,time_mesh); %initializing of exact eta to produce observation data.

      % generating observation  data  with noise_flag: we will use data g
      %only for virus u_4
											    
  [eta_guess,g] = AnalyticEta_wholeintervalnew(ext_eta,time_mesh,obs_start,obs_end,noise_flag,noise_level,meshref); %Observations and first guess for eta.
											    
  										    

 %plot(time_mesh,eta_guess,'o')
%obtain initial guess for gradient method using method of normal equations
										    
  eta_guess=LinearClassAdapt(eta_guess, time_mesh,m,meshref);

%if meshref == 1
%    ext_guess = zeros(1,size(time_mesh,2))';
%    ext_guess = 0.8;
%end

    nodes = length(time_mesh);                                  %Number of nodes in the present time mesh.
    eta = zeros(optim_maxiter,nodes);                           %Preallocation of eta (for use in for-loop).
										    
										    
    eta(1,:) = eta_guess;                                       %First guess for eta in first row.
    beta = opt_step_length*ones(1,nodes);                       %
    gamma = gamma_start;                                        %Restore beta and gamma.
    big_grad = zeros(1,nodes);                                  %Preallocation of vector for adaptivity.
    u1 = ForwardNewton(eta(1,:),time_mesh);                     %Compute initial forward sol.
    lambda1 = AdjointNewton(eta(1,:),u1,g,time_mesh,obs_start,obs_end);   %Compute adjoint sol.
    g0 = -alfa*u1(2,:).*(lambda1(1,:)-lambda1(3,:));            %Compute grad.
    grad_hist = zeros(optim_maxiter,nodes);
    grad_hist(1,:) = g0;                                        %Save gradient for later plot.
    if norm(g0) < 1000
        eta(1:end,:) = ones(length(1:optim_maxiter),1)*eta(1,:);    %Check if gradient is already small
        disp('The algorithm has converged at first step!')
        break
    end
    bm = 1/gamma;                                               %For Conjugate Gradient algorithm.
    gn = -g0;
    dn = gn;
    g0 = sign(g0);                                                  %Normalize gradient.
    eta(2,:) = eta(1,:) + beta.*g0;                                 %Compute new eta.
    iter = 0;
    for i = 2:optim_maxiter-1                                       %Here we start calculating eta.
											    gamma = gamma/i^0.5;                                        %Update gamma (reg.parameter)
        u = ForwardNewton(eta(i,:),time_mesh);                      %Update forward and adjoint sol.
        lambda = AdjointNewton(eta(i,:),u,g,time_mesh,obs_start,obs_end);
        gm = gamma*(eta(i,:)-eta(1,:)) - alfa*u(2,:).*(lambda(1,:)-lambda(3,:));         %Update gradient.
        bs = (norm(gm)/norm(gn))^2;                                 %For CG.
        dm = -gm + bs*dn;
        bm = -(gm*dn')/(gamma*(dn*dn'));                            %beta = -<g,d>/gamma<d,d>
        grad_hist(i,:) = gm;                                        %Save gradient for later plot.
        if norm(gm) < 0.001                                         %Check if gradient is small enough.
            eta(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*eta(i,:);
            grad_hist(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*grad_hist(i,:);
            disp('The algorithm has converged!')
            break
        elseif 0.999999*norm(eta(i-1,:)) < norm(eta(i,:)) && norm(eta(i,:)) < 1.000001*norm(eta(i-1,:))
            eta(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*eta(i,:);
            grad_hist(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*grad_hist(i,:);
            disp('Eta does not change!')                            %Also terminate if eta stabilizes.
            break
        %elseif norm(grad_hist(i-1,:)) < norm(grad_hist(i,:))
        %    eta(i+1,:) = eta(i,:) + 0.5*beta.*sign(grad_hist(i,:));
        %    eta(i+2:end,:) = ones(length(i+2:optim_maxiter),1)*eta(i+1,:);
        %    disp('Gradient grows.')
        %    break
        %    %Termination if the gradient increases turned out to give
        %    worse results, and is therefore disabled.
        else
            gm = sign(gm);                                      %Otherwise, continue with line search.
            for j = 1:nodes
                if eta(i,j) < 0                                 %Force eta=0 if computed eta is negative.
                    eta(i+1,j) = 0;
                elseif eta(i,j) > 1                             %Force eta=1 if computed eta > 1.
                    eta(i+1,j) = 1;
                elseif bm < 0.01
                    eta(i+1,j) = eta(i,j) + bm*gm(j);           %Use conjugate gradient if appropriate.
                else
                    if gm(j) == -gn(j)                          %Otherwise use fixed step length.
                        beta(j) = beta(j)/2;                    %If gradient change sign, halve step-length.
                    end
                    eta(i+1,j) = eta(i,j) - beta(j)*gm(j);      %Compute new eta closer to the actual solution. 
                end
            end
        end
        gn = gm;                %Save gradient for use in the CG algorithm.
        dn = dm;
        iter = iter + 1;
    end


    iter

    for j = 1:length(big_grad)  %Check where the gradient is large.
        if abs(grad_hist(end,j)) > 0.1*max(abs(grad_hist(end,:)))
            big_grad(j) = 1;
        end
    end
    refined = [];               %Start refinement of time mesh ...
    refining = [];
    k = 1;
    r = 1;
    while r < length(big_grad)
        if big_grad(r+1) == 1 && big_grad(r) == 0
            refined = [refined,time_mesh(k:r)];
        end
        if big_grad(r) == 0
            r = r + 1;
            if r == length(big_grad)
                refined = [refined,time_mesh(k:r)];
            end
            continue
        else
            %j = i;
            while big_grad(r) == 1 && r < length(time_mesh)
                refining = [refining,time_mesh(r),(time_mesh(r)+time_mesh(r+1))/2];
                r = r + 1;
                if r == length(time_mesh)
                    refining = [refining,time_mesh(r)];
                end
            end
            refined = [refined, refining];
            k = r;
        end
        refining = [];
    end
    
eta_final = eta(end,:);


%relativeerror = norm((eta(end,:)-ext_eta)/ext_eta)/m;
%relativeerror = norm((eta(end,:)-ext_eta)/ext_eta);
    relativeerror = norm(eta(end,:)-ext_eta)/norm(ext_eta);
											    
reler(meshref) = relativeerror;
numbertimes(meshref) = size(time_mesh, 2);
             
%*****************  presenting results  ***********************************
%if (meshref > 1 & relativeerror < reler(meshref-1) )

% subplot (10,2,meshref)

% ***************************  begin of visialuzation of adaptive solution ***********************
%    figure
%plot(time_mesh,ext_eta,'b','LineWidth',3)
%hold on
 
% plot(time_mesh,eta_final,'-*','LineWidth',1)	 
%    title(['Calculated \eta, number of refinements: ',num2str(meshref),'number of points',num2str(m)])		      
%      legend('exact \eta','  computed \eta (CGM)')
%hold off
%*************************  end of visualization of an adaptive solution *******************************


%figure(2)
%plot(time_mesh,ext_eta,'b','LineWidth',3)
%hold on
 
    
% plot(time_mesh,eta_final,'-*','LineWidth',1)
 	 
%    title(['Calculated \eta, number of refinements: ',num2str(meshref),'number of  points',num2str(m)])		   
%      legend('exact \eta','computed \eta') 


%    hold off


meshref

numbertimes
  %  plot(time_mesh, eta(end,:)) %Plot calculated eta for each iteration in time adaptive algorithm.

%end
reler

min_time_step
max_time_step 

    %include time partitioning
%% Visualize   computed eta 
%figure
%surf(eta)
%xlabel('time partition');
%ylabel('iteration');
%zlabel('eta');
%title('Computed drug efficiency, eta');


% presentation of the computed gradient
%figure
%surf(grad_hist)
%xlabel('time partition');
%ylabel('iteration');
%zlabel('gradient');
%title('Gradient of the functional');




%% Apply least-squares smoothing on the solution

%eta_final = eta(end,:);
N = length(eta_final);
e = ones(N,1);
D = spdiags([e -2*e e], 0:2, N-2, N);
F = speye(N) + 50*(D'*D);
eta_smooth = F\eta_final';

%*********  begin of plot comparison between exact,  computed eta via LS and computed eta via CGM **********
figure
plot(time_mesh,ext_eta,'LineWidth',2)
	 
		   hold on
plot(time_mesh,eta_guess,'--','LineWidth',2)
	plot(time_mesh,eta_final,'-* r','LineWidth',1)		   
	plot(time_mesh,eta_smooth,'-* b','LineWidth',1)
 %legend('exact \eta','guess for \eta (LS)','computed \eta (smoothed CGM)')

	   legend('exact \eta','guess for \eta (LS)','computed \eta (CGM)','computed \eta (smoothed CGM)')
	%	   legend('exact \eta','guess for \eta (LS)','computed \eta (CGM)')		   
											    xlabel('Time, t')
		  title(['Computed \eta, nr. of ref.: ',num2str(meshref-1),', nr. of obs.points: ',num2str(m)])	
hold off

%print('RecEta','-depsc')	   

%*****************  end of plot ********************************************************************
	

if ( relativeerror < eps)
			  break
end


  if (meshref > 1 & relativeerror >  reler(meshref-1) )
                  break
              end	   
end

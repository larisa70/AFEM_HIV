%Computes the exact solution of the model problem.
function [g,g_brus,g_add] = ExactNewton(eta,time_mesh,noise_level)

% Specification of initial data
%t=0;  % initial time

nodes = length(time_mesh); % Number of nodes in the time partition
%final_time = time_mesh(end);

ustart = [300;10;10;10];    %Initial values for u - write correct values            

v=ustart;
MaxIter = 1000;  % maximal number of iterations in Newton method

u=zeros(4,nodes);
u(:,1) = ustart;

%u_hist=[u];     %Save all u values for later plot
brus = zeros(4,nodes);
%final_time = 1000; % here we choose final time
%dt= final_time/(nodes-1);   %Time step 
dt = zeros(1,length(time_mesh));
for i = 1:length(dt)-1
    dt(i) = time_mesh(i+1)-time_mesh(i);   %Time step
end

for i = 1:nodes-1
    tol=1;
    iter=0;
    while tol>10^(-5) && iter < MaxIter   %Newton iterations
        %i
        %size(u)
        %size(dt)
        %size(eta)
        F= v-u(:,i)-dt(i)*Forwardfunc(v,eta(i));
        J=eye(length(ustart)) - dt(i)*ForwardfuncJac(v,eta(i));
         
%       F= v-u(:,i)-dt*Forwardfunc(v,eta);
%       J=eye(length(ustart)) - dt.*ForwardfuncJac(v,eta);
        dv = -J\F;
        
        norm(F)
        if norm(F) <10^(-5)
             disp('norm(F) s very small! Newton method stops at time ')
              time_mesh(i)
            

            break
        end
        v=v+dv; %The Newton iteration 
        iter = iter + 1 ;
tol = norm(dv,inf);
    end
    if iter == MaxIter        %If the Newton meth. does not converge
        disp('No convergence in the Newton method at time ')
        time_mesh(i)
        u(:,i+1) = u(:,i);
        continue
    end
    if v(1) < 0 || v(2) < 0 || v(3) < 0 || v(4) < 0
        warning('Exact solution algorithm yields invalid solution. Try increasing the number of nodes.')
        return
    end
   % brus(1,i) = rand*noise_level;
   % brus(2,i) = rand*noise_level;
   % brus(3,i) = rand*noise_level;
   % brus(4,i) = rand*noise_level;

% random numbers are on the interval [-1,1]

   r = -1 + (1+1).*rand;

   brus(1,i) =  r*noise_level;
    brus(2,i) = r*noise_level;
    brus(3,i) = r*noise_level;
    brus(4,i) = r*noise_level;


    u(:,i+1) = v;        
end


g=u;

g_brus = g + g.*brus;

g_add = g + g*noise_level;
end
